package com.lsj.kiosk.catcafe;

import com.lsj.utill.Cw;

public class Disp {
//	final 키워드를 붙이면 변수가 상수가 됨. 처음에 값이 들어가면 이후 값을 못바꿈.
//	상수는 이름을 다 대문자로 씀.
	final static String DOT = "☆";
	
	public static void line() {
		for(int i=0;i<32;i++) {
			Cw.w(DOT);
		}
		Cw.wn("");
	}
	public static void title() {
		line();
		Cw.wn("=============고양이카페=============");
		line();
	}
}
