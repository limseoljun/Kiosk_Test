package com.lsj.kiosk.catcafe;

import java.util.ArrayList;
import java.util.Scanner;

public class Product {
	public static ArrayList<Product> basket = new ArrayList<>();	//상품들
	public static Scanner sc = new Scanner(System.in);
	public static String cmd;
//변수 선언
	String name;
	int price;
//	오버로딩 : 함수이름이 같지만 매개변수의 갯수나 형만 달리해서 중복 추가하는 것
	
//	생성자 함수 : 변수 2개 이상의 함수
	
//	Product(String name, int price){
//		this.name = name;
//		this.price = price;
//	}
	Product(String x, int y){
		name = x;
		price = y;
	}
	Product(int price,String name){
		this.name = name;
		this.price = price;	
	}
	Product copy() {
		Product p = new Product(name,price);
		return p; 
	}
	public static Product a = new Product ("아이스 아메리카노",1500);
	public static Product b = new Product ("따뜻한 아메리카노",2000);
	public static Product c = new Product ("아이스 카페라떼",2000);
	public static Product d = new Product ("따뜻한 카페라떼",2500);
	public static Product e = new Product ("치즈케익",4500);
	public static Product f = new Product ("초코케익",4500);
	public static Product g = new Product ("마카롱",3000);
	public static Product h = new Product ("크로플",3000);
	
	public static Product[] I = {a,b,c,d,e,f,g,h};
//함수
	void info() {
		System.out.println("메뉴: "+name+"  가격: "+price+"원");
	}
}
