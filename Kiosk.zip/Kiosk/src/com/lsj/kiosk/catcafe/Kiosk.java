package com.lsj.kiosk.catcafe;

public class Kiosk {
	
	void run() {
		Disp.title();
	loop_a:
		while(true) {
		System.out.println("명령:[1.음료/ 2.디저트 / 3.계산  / 4.메뉴]");
		Disp.line();
		Product.cmd = Product.sc.next();
//		!! 같은 품목 카운트 체크를 위한 변수
		int[] ic = new int[Product.I.length] ;
		
		switch(Product.cmd) {
		case "1":
			System.out.println("음료 선택");
//			xx:      xx = 라벨이름 
			ProcMenuDrink.run_b();
			break;	
		case "2":
			System.out.println("디저트 선택");
			Disp.line();
			ProcMenuDrink.run_c();
			break;
		case "3":
//			!!!장바구니 품목의 총갯수
			int count = Product.basket.size(); 
//			!!!같은품목 카운트 중복 체크
			for(int i=0;i<count;i++) {
				for(int j=0;j<Product.I.length;j++)
					if (Product.basket.get(i).name.equals(Product.I[j].name)) {
						ic[j]= ic[j]+1;
						}
					}
//			!!!품목 이름과 갯수 표시 0개일때는 그냥 넘어감
			for(int i=0;i<8;i++) {
			if(ic[i]>0) {
				System.out.println(Product.I[i].name + ": " + ic[i] +"개" );
					}else {
				}
			}
			Disp.line();
			System.out.println("선택 상품의 수 : " + count );
			Disp.line();
//			!!!총 계산 금액
			int sum = 0;
			for(Product a:Product.basket) {
				sum = sum + a.price;
			}
			System.out.println("총 계산금액 :" + sum);
			Disp.line();
			break;
			
		case "4":
			for(Product x:Product.I) {
				x.info();
			}
			break;
			
		case "x":
			break loop_a;
		}
		}
	System.out.println("프로그램 종료");
	Disp.line();
	}
}
