package com.lsj.kiosk.catcafe;

public class ProcMenuDrink {
	
	
	public static void run_b() {
		
	loop_b:
		while(true) {
			System.out.println("명령: [1."+Product.a.name +"/2."+Product.b.name+"/3."+Product.c.name+"/4."+Product.d.name+"/x.종료]");
			Disp.line();
			Product.cmd =Product.sc.next();

			switch(Product.cmd) {
				
			case "1":
				System.out.println( Product.a.name + " 선택");
				Product.a.info();
				Disp.line();
				Product.basket.add(Product.a);
				break;
			case "2":
				System.out.println(Product.b.name + " 선택");
				Product.b.info();
				Disp.line();
				Product.basket.add(Product.b);
				break;
			case "3":
				System.out.println(Product.c.name + " 선택");
				Product.c.info();
				Disp.line();
				Product.basket.add(Product.c);
				break;
			case "4":
				System.out.println(Product.d.name + " 선택");
				Product.d.info();
				Disp.line();
				Product.basket.add(Product.d);
				break;
			case "x":
				System.out.println("선택 안함");
				Disp.line();
				break loop_b;
			}
		}
	}
	public static void run_c() {
	loop_c:
		while(true) {
			System.out.println("명령: [1."+Product.e.name +"/2."+Product.f.name+"/3."+Product.g.name+"/4."+Product.h.name+"/x.종료]");
			Disp.line();
			Product.cmd =Product.sc.next();
			
			switch(Product.cmd) {
			case "1":
				System.out.println( Product.e.name + " 선택");
				Product.e.info();
				Disp.line();
				Product.basket.add(Product.e);
				break;
			case "2":
				System.out.println(Product.f.name + " 선택");
				Product.f.info();
				Disp.line();
				Product.basket.add(Product.f);
				break;
			case "3":
				System.out.println(Product.g.name + " 선택");
				Product.g.info();
				Disp.line();
				Product.basket.add(Product.g);
				break;
			case "4":
				System.out.println(Product.h.name + " 선택");
				Product.h.info();
				Disp.line();
				Product.basket.add(Product.h);
				break;
			case "x":
				System.out.println("선택 안함");
				Disp.line();
				break loop_c;
			}

		}
	}
}
